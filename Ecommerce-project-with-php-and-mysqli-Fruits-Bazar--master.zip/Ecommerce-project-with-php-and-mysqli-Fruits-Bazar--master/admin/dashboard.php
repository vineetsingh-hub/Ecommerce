
<?php 
    $views = "dashboard";
    include ("template.php");

?>