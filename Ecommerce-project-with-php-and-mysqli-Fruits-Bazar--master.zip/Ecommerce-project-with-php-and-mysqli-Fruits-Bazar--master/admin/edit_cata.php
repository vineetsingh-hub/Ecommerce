<?php 
    $views = "edit_cata";
    include ("template.php");
?>