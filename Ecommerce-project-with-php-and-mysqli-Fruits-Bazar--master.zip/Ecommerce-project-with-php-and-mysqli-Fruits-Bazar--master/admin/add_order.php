<?php 
    $views = "add_order";
    include ("template.php");
?>