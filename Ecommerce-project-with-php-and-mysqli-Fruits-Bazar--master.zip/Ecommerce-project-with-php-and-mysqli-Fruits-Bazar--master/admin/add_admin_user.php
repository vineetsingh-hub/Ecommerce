<?php 
    $views = "add-admin-user";
    include ("template.php");

?>