<?php 
    $views = "manage_order";
    include ("template.php");

?>