<?php 
    $views ="edit_logo";
    include ("template.php");

?>