
<?php 
    $views = "manage-user";
    include ("template.php");

?>