<?php 
    $views = "edit_product";
    include ("template.php");
?>