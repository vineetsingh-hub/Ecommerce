<?php 
    $views = "manage_slider";
    include ("template.php");

?>