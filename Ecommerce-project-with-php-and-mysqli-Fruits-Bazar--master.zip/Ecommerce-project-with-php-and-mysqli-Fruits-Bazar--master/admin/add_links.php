<?php 
    $views = "add_link";
    include ("template.php");

?>