<?php 
    $views = "add-product";
    include ("template.php");

?>