1. First create a database name ecommerce in your database. Than import ecommerce.sql file in your ecommerce database.

admin access:
saifulislamsapon@gmail.com
pass:1234


user access:
saifulislamsapon@gmail.com
123